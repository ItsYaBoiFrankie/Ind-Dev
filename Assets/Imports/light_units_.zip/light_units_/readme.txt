each folder has the self-titled FBX file for the character, and includes animations with that rig. 

Let me know if there is any issue or if you need additional animations for these characters.

The skelly is supposed to be the light unit for the enemies and is very basic.

The light crusader is the good guy's foot soldier/basic tower. 